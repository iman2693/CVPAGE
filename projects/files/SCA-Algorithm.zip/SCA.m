clear all 
clc

%Iman Kianian - Mehrad Dehghan - Amin Ahmadi


%number of agent's
NO_SearchAgent=20;
% Maximum number of SCA iterations
Max_iteration=2000;

%******************************************************************
%*****************************Input Functions**********************
%******************************************************************
%f1 Ackley N. 2 Function
%******************************************************************
InputFunction=@(x)-200*exp(-0.2*sqrt(x(1)^2+x(2)^2));
LowerBound=[-32];  
UpperBound=[32]; 
NO_variables=[2]; 
%******************************************************************
%f2 Bohachevsky N. 1 Function
%******************************************************************
%InputFunction=@(x)x(1)^2+2*x(2)^2-0.3*cos(3*pi*x(1))-0.4*cos(4*pi*x(2))+0.7;
%LowerBound=[-100];  
%UpperBound=[100]; 
%NO_variables=[2]; 
%******************************************************************
%f3 Booth Function
%******************************************************************
%InputFunction=@(x)x(1)^2+2*x(2)^2-0.3*cos(3*pi*x(1))-0.4*cos(4*pi*x(2))+0.7;
%LowerBound=[-100];  
%UpperBound=[100]; 
%NO_variables=[2]; 
%******************************************************************
%f4 Booth Function
%******************************************************************
%InputFunction=@(x)(x(1)+2*x(2)-7)^2+(2*x(1)+x(2)-5)^2;
%LowerBound=[-10];  
%UpperBound=[10]; 
%NO_variables=[2]; 
%******************************************************************
%f5 Brown Function
%******************************************************************
%InputFunction=@(x)sum((x([1:9]).^2).^(x([2:10])+1)+(x([2:10]).^2).^(x([1:9]).^2+1));
%LowerBound=[-1];  
%UpperBound=[4]; 
%NO_variables=[10]; 
%******************************************************************
%f6 Drop-Wave Function
%******************************************************************
%InputFunction=@(x)-(1+(cos(12*sqrt(x(1)^2+x(2)^2))))/(0.5*(x(1)^2+x(2)^2)+2);
%LowerBound=[-5.2];  
%UpperBound=[5.2]; 
%NO_variables=[2]; 
%******************************************************************
%f7 Exponential Function
%******************************************************************
%InputFunction=@(x)-exp(-0.5*sum(x(:).^2));
%LowerBound=[-1];  
%UpperBound=[1]; 
%NO_variables=[10]; 
%******************************************************************
%f8 Griewank Function
%******************************************************************
%InputFunction=@(x)1+((sum(x(1:10).^2))./4000)-(prod(cos(x(1:10)./(sqrt([1:10])))));
%LowerBound=[-600];  
%UpperBound=[600]; 
%NO_variables=[10]; 
%******************************************************************
%f9 Leon Function
%******************************************************************
%InputFunction=@(x)100*((x(2)-x(1)^3)^2) + ((1-x(1))^2);
%LowerBound=[0];  
%UpperBound=[10]; 
%NO_variables=[2]; 
%******************************************************************
%f10 Matyas Function
%******************************************************************
%InputFunction=@(x)0.26*(x(1)^2+x(2)^2)-0.48*x(1)*x(2);
%LowerBound=[-10];  
%UpperBound=[10]; 
%NO_variables=[2]; 
%******************************************************************
%f11 Powell Sum Function
%******************************************************************
%InputFunction=@(x)sum((abs(x(1:10)).^ ([1:10])));
%LowerBound=[-1];  
%UpperBound=[1]; 
%NO_variables=[10]; 
%******************************************************************
%f12 Ridge Function
%******************************************************************
%InputFunction=@(x)x(1)+1*(sum(x(2:10).^2))^0.5;
%LowerBound=[-5];  
%UpperBound=[5]; 
%NO_variables=[10]; 
%******************************************************************
%f13 Booth Function
%******************************************************************
%InputFunction=@(x)0.5 + ((sin((x(1) .^ 2 + x(2) .^ 2) .^ 2) .^ 2) - 0.5 )./ ((1 + 0.001 * (x(1) .^2 + x(2) .^2)) .^2) ;
%LowerBound=[-100];  
%UpperBound=[100]; 
%NO_variables=[2]; 
%******************************************************************
%f14 Schaffer N. 2 Function
%******************************************************************
%InputFunction=@(x)0.5+((sin( (x(1)^2) - (x(2)^2) )^2)-0.5)/(1+0.001*(x(1)^2+x(2)^2))^2;
%LowerBound=[-600];  
%UpperBound=[600]; 
%NO_variables=[2]; 
%******************************************************************
%f15 Schaffer N. 3 Function
%******************************************************************
%InputFunction=@(x)0.5 + ((sin(cos(abs(x(1) .^ 2 - x(2) .^ 2))) .^ 2) - 0.5) ./( (1 + 0.001 * (x(1) .^2 + x(2) .^2)) .^2);
%LowerBound=[-100];  
%UpperBound=[100]; 
%NO_variables=[2]; 
%******************************************************************
%f16 Schaffer N. 4 Function
%******************************************************************
%InputFunction=@(x)0.5 + ((cos(sin(abs(x(1) .^ 2 - x(2) .^ 2))) .^ 2) - 0.5 )./ ((1 + 0.001 * (x(1) .^2 + x(2) .^2)) .^2 );
%LowerBound=[-100];  
%UpperBound=[100]; 
%NO_variables=[2]; 
%******************************************************************
%f17 Schwefel 2.20 Function
%******************************************************************
%InputFunction=@(x)sum(abs(x(:)));
%LowerBound=[-100];  
%UpperBound=[100]; 
%NO_variables=[10]; 
%******************************************************************
%f18 Schwefel 2.21 Function
%******************************************************************
%InputFunction=@(x) max(abs(x(:)));
%LowerBound=[-100];  
%UpperBound=[100]; 
%NO_variables=[10]; 
%******************************************************************
%f19 Schwefel 2.22 Function
%******************************************************************
%InputFunction=@(x) sum(abs(x(:))) + prod(abs(x(:)));
%LowerBound=[-100];  
%UpperBound=[100]; 
%NO_variables=[10]; 
%******************************************************************
%f20 Schwefel 2.23 Function
%******************************************************************
%InputFunction=@(x) sum(x(:).^10);
%LowerBound=[-10];  
%UpperBound=[10]; 
%NO_variables=[10]; 
%******************************************************************
%f21 Sphere Function
%******************************************************************
%InputFunction=@(x) sum(x(:).^ 2);
%LowerBound=[-5.12];  
%UpperBound=[5.12]; 
%NO_variables=[10]; 
%******************************************************************
%f22 Sum Squares Function
%******************************************************************
%InputFunction=@(x) sum([1:10].*x(1:10).^2);
%LowerBound=[-10];  
%UpperBound=[10]; 
%NO_variables=[10]; 
%******************************************************************
%f23 Booth Function
%******************************************************************
%InputFunction=@(x)(2*x(1).^2)-(1.05*(x(1).^4))+((x(1).^6)/6)+x(1).*x(2)+x(2).^2;
%LowerBound=[-5];  
%UpperBound=[5];  
%NO_variables=[2]; 
%******************************************************************
%f24 Xin-She Yang N. 3 Function
%******************************************************************
%InputFunction=@(x)exp(sum((x/15).^(2*5),2))-(2*exp(-sum(x.^2,2)) .* prod(cos(x).^2,2));
%LowerBound=[-2 * pi];  
%UpperBound=[2 * pi];  
%NO_variables=[10]; 
%******************************************************************
%f25 Zakharov Function
%******************************************************************
%InputFunction=@(x)(sum(x([1:10]).^2) + (sum(0.5 .* [1:10] .* x([1:10]))).^2 + (sum(0.5 .* [1:10] .* x([1:10]))).^4);
%LowerBound=[-5];  
%UpperBound=[10];  
%NO_variables=[10]; 





display('SCA : Started');
display('SCA : Approximate problem answers in iterations');

%We create a set of random starting numbers
%Calculate the number boundaries
Boundary_no= size(UpperBound,2);
if Boundary_no==1
    X=rand(NO_SearchAgent,NO_variables).*(UpperBound-LowerBound)+LowerBound;
end

% If each variable in Input has a different LowerBound and UpperBound
if Boundary_no>1
    for i=1:NO_variables
        ub_i=UpperBound(i);
        lb_i=LowerBound(i);
        X(:,i)=rand(NO_SearchAgent,1).*(ub_i-lb_i)+lb_i;
    end
end

%end of Initialization

Destination_position=zeros(1,NO_variables);
Destination_fitness=inf;


Objective_values = zeros(1,size(X,1));

% Calculate the fitness of the first set and find the best one
for i=1:size(X,1)
    Objective_values(1,i)=InputFunction(X(i,:));
    if i==1
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    elseif Objective_values(1,i)<Destination_fitness
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    end
    
end

%Main loop
t=2; % start from the second iteration since the first iteration was dedicated to calculating the fitness
while t<=Max_iteration
    
    % Eq. (3.4)
    a = 2;
    r1=a-t*((a)/Max_iteration); % r1 decreases linearly from a to 0
    
    % Update the position of solutions with respect to destination
    for i=1:size(X,1) % in i-th solution
        for j=1:size(X,2) % in j-th dimension
            
            % Update r2, r3, and r4 for Eq. (3.3)
            r2=(2*pi)*rand();
            r3=2*rand;
            r4=rand();
            
            % Eq. (3.3)
            if r4<0.5
                % Eq. (3.1)
                X(i,j)= X(i,j)+(r1*sin(r2)*abs(r3*Destination_position(j)-X(i,j)));
            else
                % Eq. (3.2)
                X(i,j)= X(i,j)+(r1*cos(r2)*abs(r3*Destination_position(j)-X(i,j)));
            end
            
        end
    end
    
    for i=1:size(X,1)
         
        % Check if solutions go outside the search spaceand bring them back
        ubFlag=X(i,:)>UpperBound;
        lbFlag=X(i,:)<LowerBound;
        X(i,:)=(X(i,:).*(~(ubFlag+lbFlag)))+UpperBound.*ubFlag+LowerBound.*lbFlag;
        
        % Calculate the objective values
        Objective_values(1,i)=InputFunction(X(i,:));
        
        % Update the destination if there is a better solution in objective values
        if Objective_values(1,i)<Destination_fitness
            Destination_position=X(i,:);
            Destination_fitness=Objective_values(1,i);
        end
    end
    
    
    
    % Display the iteration and best optimum obtained so far
    if mod(t,50)==0
        display(['At iteration ', num2str(t), ' the optimum is ', num2str(Destination_fitness)]);
    end
    
    % Increase the iteration counter
    t=t+1;
end
display('SCA : Ended');
display(['f(x*) or Destination_fitness:',num2str(Destination_fitness)]);
display(['x* or Destination_position: ',num2str(Destination_position)]);
