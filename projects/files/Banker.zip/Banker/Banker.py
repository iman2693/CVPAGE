import csv
from PyQt5 import QtCore, QtGui, QtWidgets
__author__='Iman Kianian'
global Allocation

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(652, 346)
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(40, 10, 561, 81))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.calculate = QtWidgets.QPushButton(Form)
        self.calculate.setGeometry(QtCore.QRect(250, 110, 151, 71))
        font = QtGui.QFont()
        font.setPointSize(9)
        self.calculate.setFont(font)
        self.calculate.setDefault(True)
        self.calculate.setObjectName("calculate")
        self.ResultLabel = QtWidgets.QLabel(Form)
        self.ResultLabel.setGeometry(QtCore.QRect(70, 250, 401, 71))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.ResultLabel.setFont(font)
        self.ResultLabel.setObjectName("ResultLabel")
        self.logo = QtWidgets.QLabel(Form)
        self.logo.setGeometry(QtCore.QRect(510, 245, 81, 81))
        self.logo.setText("")
        self.logo.setObjectName("logo")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def findaprocess(self,Available, Need,Allocation):
        flag = []
        for i in range(len(Need)):
            flag.append(False)
        for i in range(len(Need)):
            if all(v == 0 for v in Need[i]) and all(v == 0 for v in Allocation[i]):
                flag[i] = True
        for i in range(len(Need)):
            if flag[i] == False and all(v <= x for (v, x) in zip(Need[i], Available)):
                return i  # Find A Process
        return -1  # If Do Not Find A Process

    def SafeOrUnSafe(self,Need):
        for i in range(len(Need)):
            for j in range(len(Need[i])):
                if Need[i][j] != 0:
                    return False
        return True

    def calculatee(self):
        ResourceFile = 'Resource.csv'
        with open(ResourceFile, 'r') as p:
            # reads csv into a list of lists
            Resource = [list(map(int, rec)) for rec in csv.reader(p, delimiter=',')]
        Resource = Resource[0]

        MaxFile = 'Max.csv'
        with open(MaxFile, 'r') as p:
            # reads csv into a list of lists
            Max = [list(map(int, rec)) for rec in csv.reader(p, delimiter=',')]

        AllocationFile = 'Allocation.csv'
        with open(AllocationFile, 'r') as p:
            # reads csv into a list of lists
            Allocation = [list(map(int, rec)) for rec in csv.reader(p, delimiter=',')]
        m = len(Resource)  # ==> Number OF Resource
        n = len(Max)  # ==> Number OF Process

        Available = []
        col = 0
        for i in range(m):  # Compute Available
            Sum = 0
            for j in range(n):
                Sum += Allocation[j][i]
            Available.append((Resource[col] - Sum))
            col += 1
        Need = []
        for i in range(n):  # Compute Need
            temp = []
            for j in range(m):
                temp.append(Max[i][j] - Allocation[i][j])
            Need.append(temp)

        while self.findaprocess(Available, Need, Allocation) != -1:
            k = self.findaprocess(Available, Need, Allocation)
            for i in range(m):
                Need[k][i] = 0
                Available[i] = Available[i] + Allocation[k][i]
                Allocation[k][i] = 0
        if self.SafeOrUnSafe(Need):
            self.ResultLabel.setStyleSheet('color:green;')
            self.ResultLabel.setText('* Your System Is Safe')
            self.logo.setPixmap(QtGui.QPixmap("check.png"))
        else:
            self.ResultLabel.setStyleSheet('Color:red;')
            self.ResultLabel.setText('* Your System Isn\'t Safe')
            self.logo.setPixmap(QtGui.QPixmap("block.png"))

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label.setText(_translate("Form", "* Enter Your Data  In CSV Files . ( Max.csv , Allocation.csv , Resource.csv )"))
        self.calculate.setText(_translate("Form", "Calculate"))
        self.calculate.clicked.connect(self.calculatee)


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())
