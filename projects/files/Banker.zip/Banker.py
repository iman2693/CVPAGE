__author__='Iman Kianian'

def findaprocess(Available,Need):
    flag=[]
    for i in range(len(Need)):
        flag.append(False)
    for i in range(len(Need)):
        if all(v==0 for v in Need[i]) and all(v==0 for v in Allocation[i]) :
            flag[i]=True
    for i in range(len(Need)):
        if flag[i]==False and all(v<=x for (v,x) in zip(Need[i],Available)):
            return i   #If Find A Process
    return -1  #If Do Not Find A Process


def SafeOrUnSafe(Need):
    for i in range(len(Need)):
        for j in range(len(Need[i])):
            if Need[i][j]!=0:
                return False
    return True

# Input Way 1

# m=int(input('How Many Source Do You Want to have ? : '))
# n=int(input('How Many Process Do You Want to have ? : '))
# Resource=[]
# for i in range(m): # Get Resource Array 2D
#     Resource.append(int(input("Enter Resorce[{0}] : ".format(i+1))))
# Max=[]
# for i in range(n): # Get Max Array 2D
#     temp=[]
#     for j in range(m):
#         temp.append(int(input("Enter Max[{0}][{1}] : ".format(i+1,j+1))))
#     Max.append(temp)
# Allocation=[]
# for i in range(n):  # Get Allocation Array 2D
#     temp=[]
#     for j in range(m):
#         temp.append(int(input("Enter Allocation[{0}][{1}] : ".format(i+1,j+1))))
#     Allocation.append(temp)


#TEST 1  ===> SYSTEM IS SAFE
# m=3
# n=4
# Resource=[9,3,6]
# Max=[[6,2,2],[6,1,3],[3,1,4],[4,2,2]]
# Allocation=[[1,0,0],[6,1,2],[2,1,1],[0,0,2]]

#TEST 2  ===> SYSTEM ISN'T SAFE
m=2
n=4
Resource=[14,7]
Max=[[9,5],[2,6],[2,2],[5,0]]
Allocation=[[7,2],[1,3],[1,1],[3,0]]


Available=[]
col=0
for i in range(m):  #Compute Available
    Sum = 0
    for j in range(n):
        Sum+=Allocation[j][i]
    Available.append((Resource[col] - Sum))
    col+=1
Need=[]
for i in range(n): #Compute Need
    temp=[]
    for j in range(m):
        temp.append(Max[i][j]-Allocation[i][j])
    Need.append(temp)
# print(Available)
# print(Need)
while findaprocess(Available,Need)!=-1:
    k=findaprocess(Available,Need)
    for i in range(m):
        Need[k][i]=0
        Available[i]=Available[i]+Allocation[k][i]
        Allocation[k][i]=0
if SafeOrUnSafe(Need):
    print("Your System Is Safe")
    print(Available)
else:
    print("Your System Isn't Safe")





